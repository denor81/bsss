#!/usr/bin/env bash
# bsss-main.sh
# Основной скрипт для последовательного запуска модулей системы
# Usage: ./bsss-main.sh

set -Eeuo pipefail

# Константы
readonly UTIL_NAME="bsss"
# shellcheck disable=SC2155
readonly THIS_DIR_PATH="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")" )" && pwd)"
readonly MODULES_DIR="${THIS_DIR_PATH}/modules"
# shellcheck disable=SC2034
# shellcheck disable=SC2155
readonly CURRENT_MODULE_NAME="$(basename "$0")"


# Подключаем библиотеку функций логирования
# shellcheck disable=SC1091
source "${THIS_DIR_PATH}/lib/logging.sh"

# ========== ФУНКЦИИ ЭКСПРЕСС-АНАЛИЗА ==========

# Собирает экспресс-статус от всех модулей
collect_modules_status() {
    log_info "Сбор статуса модулей..."
    
    local modules_list
    modules_list=$(get_available_modules) || return 1
    
    echo "#####BSSS#####"
    
    local has_error=0
    
    while IFS= read -r module_path; do
        if [[ -n "$module_path" ]]; then
            local module_name
            module_name=$(basename "$module_path")
            
            if check_module_exists "$module_name"; then
                local status_output
                status_output=$(get_module_status "$module_name")
                
                # Форматируем вывод и проверяем на ошибки
                if ! format_module_status "$status_output"; then
                    has_error=1
                fi
            fi
        fi
    done <<< "$modules_list"
    
    echo "#############"
    echo ""
    
    # Если есть ошибки, прерываем выполнение
    if [[ $has_error -eq 1 ]]; then
        log_error "Обнаружены критические ошибки в модулях. Выполнение прервано."
        exit 1
    fi
}

# Получает статус от модуля
get_module_status() {
    local module_name="$1"
    local module_path="${MODULES_DIR}/${module_name}"
    
    # Запускаем модуль с параметром -c и захватываем вывод
    local status_output
    status_output=$(bash "$module_path" -c 2>/dev/null)
    echo "$status_output"
}

# Форматирует вывод статуса модуля
format_module_status() {
    local output="$1"
    
    local module=$(echo "$output" | grep "^module=" | cut -d'=' -f2-)
    local status=$(echo "$output" | grep "^status=" | cut -d'=' -f2-)
    local message=$(echo "$output" | grep "^message=" | cut -d'=' -f2-)
    
    # Формируем одну строку с информацией
    echo "# $module: $message"
    
    # Если статус не "0", возвращаем ошибку
    if [[ "$status" != "0" ]]; then
        log_error "Модуль $module вернул статус ошибки: $status"
        return 1
    fi
    
    return 0
}

hello() {
    log_info "Запуск основной системы ${UTIL_NAME^^}"
}

# Проверяет существование модуля
check_module_exists() {
    local module_name="$1"
    local module_path="${MODULES_DIR}/${module_name}"
    
    if [[ ! -f "$module_path" ]]; then
        log_error "Модуль не найден: $module_path"
        return 1
    fi
    
    return 0
}

# Запускает модуль в изолированном процессе
run_module() {
    local module_name="$1"
    local module_path="${MODULES_DIR}/${module_name}"
    
    log_info "Запуск модуля: $module_name"
    
    # Запускаем модуль в изолированном процессе через bash
    bash "$module_path"
    local exit_code=$?
    
    if [[ $exit_code -eq 0 ]]; then
        log_success "Модуль $module_name выполнен успешно"
    else
        log_error "Модуль $module_name завершился с ошибкой (код: $exit_code)"
        return 1
    fi
    
    return 0
}

# Получает список всех доступных модулей
get_available_modules() {
    if [[ -d "$MODULES_DIR" ]]; then
        # Ищем все исполняемые файлы, включая .sh и без расширения
        find "$MODULES_DIR" -type f \( -name "*.sh" -o -executable \) | sort
    else
        log_error "Директория модулей не найдена: $MODULES_DIR"
        return 1
    fi
}

# Основная функция-стартер для запуска модулей
start_modules() {
    log_info "Начинаю последовательный запуск модулей..."
    
    local modules_list
    modules_list=$(get_available_modules) || {
        log_error "Ошибка при получении списка модулей"
        return 1
    }
    
    if [[ -z "$modules_list" ]]; then
        log_info "Модули для запуска не найдены"
        return 1
    fi
    
    local module_count=0
    local success_count=0
    
    while IFS= read -r module_path; do
        if [[ -n "$module_path" ]]; then
            local module_name
            module_name=$(basename "$module_path")
            
            module_count=$((module_count + 1))
            
            if check_module_exists "$module_name"; then
                if run_module "$module_name"; then
                    success_count=$((success_count + 1))
                else
                    log_error "Ошибка при выполнении модуля: $module_name"
                    # Продолжаем выполнение остальных модулей даже при ошибке
                fi
            fi
        fi
    done <<< "$modules_list"
    
    log_info "Завершено: $success_count из $module_count модулей выполнено успешно"
    
    return 0
}

# Основная функция
main() {
    # Сначала экспресс-анализ
    collect_modules_status
    
    # Затем полный запуск модулей
    start_modules
}

# (Guard): Выполнять main ТОЛЬКО если скрипт запущен, а не импортирован
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main
fi

log_success "Завершен"
