#!/usr/bin/env bash
# Установлен ufw или нет
# MODULE_ORDER: 70
# MODULE_TYPE: check

set -Eeuo pipefail

readonly PROJECT_ROOT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")" )" && pwd)/.."

source "${PROJECT_ROOT}/lib/vars.conf"
source "${PROJECT_ROOT}/lib/logging.sh"
source "${PROJECT_ROOT}/lib/user_confirmation.sh"
source "${PROJECT_ROOT}/modules/helpers/common.sh"
source "${PROJECT_ROOT}/modules/helpers/ufw.sh"

# @type:        Orchestrator
# @description: Проверяет наличие UFW и устанавливает при необходимости
# @params:      нет
# @stdin:       нет
# @stdout:      нет
# @exit_code:   0 - UFW установлен или уже был установлен
#               1 - ошибка установки или отказ от установки
check() {
    if command -v ufw > /dev/null 2>&1; then
        ufw::orchestrator::log_statuses
    else
        log_error "UFW не установлен"
        if io::confirm_action "Установить UFW сейчас? [apt update && apt install ufw -y]" || return; then
            if ! (apt update && apt install ufw -y); then
                log_error "Ошибка при установке UFW"
                return 1
            else
                if command -v ufw > /dev/null 2>&1; then
                    log_info "UFW успешно установлен"
                else
                    log_info "UFW установлен - перезапустите скрипт"
                    return 1
                fi
            fi
        fi
    fi


}

# @type:        Orchestrator
# @description: Точка входа модуля проверки UFW
# @params:      нет
# @stdin:       нет
# @stdout:      нет
# @exit_code:   0 - проверка прошла успешно
#               2 - отказ пользователя от установки UFW
#               $? - ошибка проверки
main() {
    check
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi