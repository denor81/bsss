#!/usr/bin/env bash
# module-01.sh
# Тестовый
# Возвращает код успеха 0

set -Eeuox pipefail

# shellcheck disable=SC2155
readonly THIS_DIR_PATH="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")" )" && pwd)"
# Получаем только имя файла из переменной $0
# shellcheck disable=SC2155
readonly SCRIPT_NAME=$(basename "$0")
# shellcheck disable=SC2034
readonly CURRENT_MODULE_NAME="$SCRIPT_NAME"

CHECK_FLAG=1

# Коды возврата
readonly SUCCESS=0
readonly ERR_RUN_FLAG=1

# Подключаем библиотеку функций логирования
# shellcheck disable=SC1091
source "${THIS_DIR_PATH}"/../lib/logging.sh

# check() {
#     log_info "ЗАПУСК МОДУЛЯ $SCRIPT_NAME В РЕЖИМЕ ПРОВЕРКИ"
    
#     # Проверяем текущий активный порт SSH
#     if [[ -n "${SSH_CLIENT:-}" ]]; then
#         local ssh_port="${SSH_CLIENT##* }"
#         log_info "Текущий активный порт SSH: $ssh_port"
#     else
#         log_error "Не возможно определлить порт через SSH_CLIENT (Возможно виртуальная машина)"
#         # Fallback
#     fi
    
#     return "$SUCCESS"
# }

check() {
    log_info "ЗАПУСК МОДУЛЯ $SCRIPT_NAME В РЕЖИМЕ ПРОВЕРКИ"
    
    local ssh_port
    
    # 1. Попытка через SSH_CLIENT (если мы подключены по SSH)
    if [[ -n "${SSH_CLIENT:-}" ]]; then
        ssh_port="${SSH_CLIENT##* }"
        log_info "Определен порт через SSH_CLIENT: $ssh_port"
        echo "$ssh_port"
        return "$SUCCESS"
    fi
    
    # 2. Используем ss с более точной фильтрацией
    if command -v ss >/dev/null 2>&1; then
        # Ищем процессы sshd (PID можно получить через systemctl или ps)
        local sshd_pids
        sshd_pids=$(ps aux | grep -E '[s]shd:' | awk '{print $2}' | head -1)
        
        if [[ -n "$sshd_pids" ]]; then
            # Ищем порты, которые прослушивает sshd
            ssh_port=$(sudo ss -tlnp 2>/dev/null | \
                       awk -v pid="$sshd_pids" \
                       '$7 ~ pid && /LISTEN/ {split($4, a, ":"); print a[length(a)]}' | \
                       head -1)
        fi
        
        # Если не нашли по PID, ищем по имени
        if [[ -z "$ssh_port" ]]; then
            ssh_port=$(sudo ss -tln 2>/dev/null | \
                       awk '$1 == "LISTEN" && /ssh/ {split($4, a, ":"); print a[length(a)]}' | \
                       head -1)
        fi
    fi
    
    # 3. Альтернатива через netstat
    if [[ -z "$ssh_port" ]] && command -v netstat >/dev/null 2>&1; then
        ssh_port=$(sudo netstat -tlnp 2>/dev/null | \
                   awk '/sshd/ && /LISTEN/ {split($4, a, ":"); print a[length(a)]}' | \
                   head -1)
    fi
    
    # 4. Чтение конфигурации sshd
    if [[ -z "$ssh_port" ]]; then
        local sshd_configs=("/etc/ssh/sshd_config" "/etc/sshd_config")
        for config in "${sshd_configs[@]}"; do
            if [[ -f "$config" ]]; then
                ssh_port=$(grep -E '^Port[[:space:]]+' "$config" 2>/dev/null | \
                          awk '{print $2}' | head -1)
                [[ -n "$ssh_port" ]] && break
            fi
        done
    fi
    
    # 5. Проверка systemd сокетов
    if [[ -z "$ssh_port" ]]; then
        if systemctl is-active ssh.socket >/dev/null 2>&1; then
            ssh_port=$(systemctl show ssh.socket | \
                       grep -oP 'ListenStream=\K[^:]+$' | head -1)
        fi
    fi
    
    # 6. Проверка активных подключений (если кто-то уже подключен)
    if [[ -z "$ssh_port" ]] && [[ -f /proc/net/tcp ]]; then
        ssh_port=$(awk '$2 ~ /:0016$/ || $2 ~ /:[0-9A-F]{4}$/ {print substr($2, index($2,":")+1)}' \
                   /proc/net/tcp 2>/dev/null | \
                   head -1 | \
                   xargs -I {} echo "ibase=16; {}" | bc 2>/dev/null)
    fi
    
    # 7. Проверка по умолчанию
    if [[ -z "$ssh_port" ]]; then
        ssh_port="22"
        log_warning "Порт SSH не определен, используется порт по умолчанию: $ssh_port"
    else
        log_info "Определен порт SSH: $ssh_port"
    fi
    
    log_info "$ssh_port"
    return "$SUCCESS"
}

# Альтернативный вариант - более компактный и надежный
get_ssh_port() {
    local port
    
    # 1. Через ss с поиском процесса sshd
    if command -v ss >/dev/null 2>&1; then
        port=$(sudo ss -tlnp 2>/dev/null | \
               awk 'BEGIN {IGNORECASE=1} /sshd/ && /LISTEN/ {
                   split($4, a, ":");
                   port = a[length(a)];
                   if (port ~ /^[0-9]+$/) {
                       print port;
                       exit 0
                   }
               }')
    fi
    
    # 2. Если не сработало, проверяем все открытые порты SSH
    if [[ -z "$port" ]]; then
        for test_port in 22 2222 22222 2200 2022; do
            if sudo ss -tln 2>/dev/null | grep -q ":${test_port}[[:space:]]"; then
                port="$test_port"
                break
            fi
        done
    fi
    
    # 3. Проверка через lsof (если есть)
    if [[ -z "$port" ]] && command -v lsof >/dev/null 2>&1; then
        port=$(sudo lsof -iTCP -sTCP:LISTEN -n -P 2>/dev/null | \
               awk '/sshd/ {split($9, a, ":"); print a[2]; exit}')
    fi
    
    log_info "${port:-22}"
}


run() {
    log_info "ЗАПУСК МОДУЛЯ $SCRIPT_NAME В СТАНДАРТНОМ РЕЖИМЕ"
    return "$SUCCESS"
}

main() {
    if [[ "$CHECK_FLAG" -eq 1 ]]; then
        check
        return $?
    elif [[ "$CHECK_FLAG" -eq 0 ]]; then
        run
        return $?
    fi
    log_error "Не определен флаг запуска"
    return "$ERR_RUN_FLAG"
}

main 
